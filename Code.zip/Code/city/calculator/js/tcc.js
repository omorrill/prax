(function($) {
  // Code that uses jQuery's $ can follow here.
  
})(jQuery);